package guiproject;

import java.sql.Date;
import java.util.*;
import java. sql.Time;
import java.text.SimpleDateFormat;
public class Main 
{

	public static void main(String[] args) 
	{
		
		java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		java.sql.Time time = new Time(System.currentTimeMillis());
		
		//Customer john = new Customer();
		//john.newCustomer(789,"paul", "mar", date, 0);
		//john.updateCustomer(42765, "Grace", "Williams", date, 760);
		//john.deleteCustomer(42765);
		
		//Customer mary = new Customer();
		//mary.newCustomer(01222, "mary", "adams", date, 1);
		
		Order order = new Order();
		String daaate = "2022-05-10"; 
		Date d1 = Date.valueOf(daaate);
		order.newOrder(d1, time, 10);
		//order.updateOrder(1, date, time, 01111);
		//order.deleteOrder(4);
		
		//Professor john = new Professor();
		//john.updateProfessor(42765, "science", "office 2", "chairs");
		
		//Student john = new Student();
		//john.updateStudent(42765, date , date, "computer science", "none");
		
		//HistoricalPrice test = new HistoricalPrice();
		//test.newHistoricalPrice(10.52, date, 1111);
		
		//MenuItem food = new MenuItem();
		//food.newMenuItem("burger", 5);
		//food.updateMenuItem(1, "fries", 5);
		//food.deleteMenuItem(1);
		
		//Food_Order test = new Food_Order();
		//test.newFoodOrder(2, 2, 3);
		//test.deleteFoodOrder(2, 2);
		
	}

}
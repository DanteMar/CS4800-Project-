package guiproject;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDataAccess {

	public static Connection verifyCredentials() throws ClassNotFoundException, SQLException {

		final String URL = "jdbc:postgresql://localhost:5432/postgres";

		final String USER = "postgres";

		final String PWD = "123"; //change for your local database

		try 
		{   
			Connection connection = DriverManager.getConnection(URL, USER, PWD);
			System.out.println("Database connected!");
	
		    return connection;	    
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		    throw new IllegalStateException("Cannot connect the database!", e);

		}
	}
	
	public Connection get_connection() {
		final String URL = "jdbc:postgresql://localhost:5432/postgres";

		final String USER = "postgres";

		final String PWD = "123"; //change for your local database
		
		try 
		{   
			Connection connection = DriverManager.getConnection(URL, USER, PWD);
			System.out.println("Database connected!");
	
		    return connection;	    
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		    throw new IllegalStateException("Cannot connect the database!", e);

		}
		
	}
	public static ResultSet getRevenueSet(Date d1, Date d2) //returns a resultset of broncoid, fname, lastname and orderdate between a 2 date range
    {
    	try
		{
			Connection connection = LoginDataAccess.verifyCredentials();
			PreparedStatement stmt = connection.prepareStatement("select customer.broncoid, customer.firstname, customer.lastname, aorder.odate  FROM customer INNER JOIN aorder ON aorder.broncoid = customer.broncoid where odate between ? and ?");
			stmt.setDate(1, d1);
        	stmt.setDate(2, d2);
			ResultSet rs = stmt.executeQuery();
			return rs;
		}
		catch (Exception e) {
			System.out.println(e);
		}
    	return null;
    }
}
